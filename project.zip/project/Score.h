//
// Created by Arshia on 7/5/2023.
//
#include "SFML/Graphics.hpp"
#include "iostream"
#include "string"
#ifndef PROJECT_SCORE_H
#define PROJECT_SCORE_H


class Score {
public:
    Score(int currScore);
    void drawScore(sf:: RenderWindow &window);

private:
    sf::Font fontScore;
    sf::Text score[1];
};

#endif //PROJECT_SCORE_H
