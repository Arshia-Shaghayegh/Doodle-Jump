//
// Created by Arshia on 7/6/2023.
//
#include "SFML/Graphics.hpp"
#include "iostream"
#define  MAX_NUM_GAMEOVER 5
#ifndef PROJECT_GAMEOVER_H
#define PROJECT_GAMEOVER_H


class GameOver {
public:
    GameOver(float width,float height,int currScore,std::string myname);
    void drawGameover(sf:: RenderWindow &window);
    void MoveUp();
    void MoveDown();
    int GetPressedItem(){
        return  selectedItemsIndexOver;
    }
private:
    int selectedItemsIndexOver;
    sf::Font fontOver;
    sf::Text over[MAX_NUM_GAMEOVER];

};

#endif //PROJECT_GAMEOVER_H
