//
// Created by BiaDigi.Com on 7/6/2023.
//

#include "GameOver.h"
#include "iostream"
#include "string"
#include "fstream"
#include <stdio.h>
#include <stdlib.h>
FILE *ptr;

GameOver::GameOver(float width, float height,int currScore,std::string myname) {
    if(!fontOver.loadFromFile("G:\\project\\DoodleJump.ttf")){
        //handle error
    }
    over[0].setFont(fontOver);
    over[0].setColor(sf::Color::Black);
    over[0].setOutlineColor({0,0,0});
    over[0].setOutlineThickness(0.5);
    over[0].setCharacterSize(25);
    over[0].setString(std::to_string(currScore));
    over[0].setPosition(sf::Vector2f(width/2+40,height/(MAX_NUM_GAMEOVER -1)*1.5 ));

    FILE *fptr;
    fptr = fopen("G:\\project\\highestScore.txt", "r");
    char myString[20];
    fgets(myString, 20, fptr);
    int highest= atoi(myString);
    fclose(fptr);
    if(highest>=currScore){
        over[1].setFont(fontOver);
        over[1].setColor(sf::Color::Black);
        over[1].setOutlineColor({0,0,0});
        over[1].setOutlineThickness(0.5);
        over[1].setCharacterSize(25);
        over[1].setString(myString);
        over[1].setPosition(sf::Vector2f(width/2+40,height/(MAX_NUM_GAMEOVER -1)*1.72));
    }
    if(currScore>highest){
        std::ofstream MyFile("G:\\project\\highestScore.txt");
        std::string str=std::to_string(currScore);
        MyFile << str;
        MyFile.close();
        over[1].setFont(fontOver);
        over[1].setColor(sf::Color::Black);
        over[1].setOutlineColor({0,0,0});
        over[1].setOutlineThickness(0.5);
        over[1].setCharacterSize(25);
        over[1].setString(str);
        over[1].setPosition(sf::Vector2f(width/2+40,height/(MAX_NUM_GAMEOVER -1)*1.72));
    }



    over[2].setFont(fontOver);
    over[2].setColor(sf::Color::Black);
    over[2].setOutlineColor({0,0,0});
    over[2].setOutlineThickness(0.5);
    over[2].setCharacterSize(25);
    if(!myname.empty()){
        myname.pop_back();
        over[2].setString(myname);
    }
    else
        over[2].setString("NO Name Entered :(");
    over[2].setPosition(sf::Vector2f(width/2+15,height/(MAX_NUM_GAMEOVER - 1)*1.94 ));

    over[3].setFont(fontOver);
    over[3].setColor(sf::Color::Red);
    over[3].setOutlineColor({128, 9, 9});
    over[3].setOutlineThickness(2);
    over[3].setCharacterSize(28);
    over[3].setString("Play again");
    over[3].setPosition(sf::Vector2f(width/2-33,height/(MAX_NUM_GAMEOVER + 1)*4 -10));

    over[4].setFont(fontOver);
    over[4].setColor(sf::Color::Black);
    over[4].setOutlineColor({107, 103, 103});
    over[4].setOutlineThickness(2);
    over[4].setCharacterSize(35);
    over[4].setString("Menu");
    over[4].setPosition(sf::Vector2f(width/2+40,height/(MAX_NUM_GAMEOVER + 1)*4.75));
    selectedItemsIndexOver=3;

}
void GameOver::drawGameover(sf::RenderWindow &window) {
    for(int i=0;i<MAX_NUM_GAMEOVER;i++){
        window.draw(over[i]);
    }
}
void GameOver::MoveUp() {
    if(selectedItemsIndexOver == 4){
        over[selectedItemsIndexOver].setColor(sf::Color::Black);
        over[selectedItemsIndexOver].setOutlineColor({107, 103, 103});
        selectedItemsIndexOver =3;
        over[selectedItemsIndexOver].setColor(sf::Color::Red);
        over[selectedItemsIndexOver].setOutlineColor({128, 9, 9});
    }
}
void GameOver::MoveDown()  {
    if(selectedItemsIndexOver==3){
        over[selectedItemsIndexOver].setColor(sf::Color::Black);
        over[selectedItemsIndexOver].setOutlineColor({107, 103, 103});
        selectedItemsIndexOver =4;
        over[selectedItemsIndexOver].setColor(sf::Color::Red);
        over[selectedItemsIndexOver].setOutlineColor({128, 9, 9});
    }
}