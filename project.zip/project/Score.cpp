//
// Created by Arshia on 7/5/2023.
//

#include "Score.h"
#include "iostream"
#include "string"
Score::Score(int currScore)  {
    if(!fontScore.loadFromFile("G:\\project\\DoodleJump.ttf")){
        //handle error
    }
    score[0].setFont(fontScore);
    score[0].setOutlineColor({11, 77, 71});
    score[0].setOutlineThickness(2);
    score[0].setColor(sf::Color{28, 252, 234});
    score[0].setCharacterSize(24);;
    std::string str="Score :    ";
    str= str+ std::to_string(currScore);
    score[0].setString(str);
    score[0].setPosition(sf::Vector2f(20,0));
}
void Score::drawScore(sf::RenderWindow &window) {
    for(int i=0;i<1;i++){
        window.draw(score[i]);
    }
}
