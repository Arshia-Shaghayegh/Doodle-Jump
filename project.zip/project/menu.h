//
// Created by Arshia on 7/5/2023.
//
#include "SFML/Graphics.hpp"

#define  MAX_NUMBER_OF_ITEMS 3
#ifndef PROJECT_MENU_H
#define PROJECT_MENU_H


class Menu {
public:
    Menu(float width,float height);

    void draw(sf:: RenderWindow &window);
    void MoveUp();
    void MoveDown();
    int GetPressedItem(){
        return  selectedItemsIndex;
    }
private:
    int selectedItemsIndex;
    sf::Font font;
    sf::Text menu[MAX_NUMBER_OF_ITEMS];

};


#endif //PROJECT_MENU_H
