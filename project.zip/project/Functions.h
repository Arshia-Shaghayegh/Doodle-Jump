//
// Created by Arshia on 7/6/2023.
//
#ifndef PROJECT_FUNCTIONS_H
#define PROJECT_FUNCTIONS_H
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <time.h>
#include "Animation.h"
#include "Animation.cpp"
#include "menu.h"
#include "menu.cpp"
#include "Score.h"
#include "Score.cpp"
#include "Mode.cpp"
#include "Mode.h"
#include "GameOver.cpp"
#include "GameOver.h"
#include "TextBox.h"
using namespace sf;
struct platform
{
    int x, y;
};
struct platformJump
{
    int x, y;
};
struct platformtampo
{
    int x, y;
};
struct EnemyS
{
    int x, y;
};
int currScore = 0;
std::string myname;
Score score(0);
int windowWidth = 400;
int windowHeight = 545;
int page;
int modepage;
bool gamePause;

int gameIsOver()
{
    RenderWindow OverMenu(VideoMode(windowWidth, windowHeight), "Doodle Jump Game");
    Texture OverBackTexture;
    OverBackTexture.loadFromFile("G:\\project\\images\\gameover.png");
    Sprite OverBackSprite(OverBackTexture);
    GameOver gameOver(windowWidth, windowHeight, currScore, myname);
    OverMenu.setFramerateLimit(60);

    SoundBuffer menubutBuffer;
    menubutBuffer.loadFromFile("G:\\project\\sounds\\menuBut.wav");
    Sound menubut;
    menubut.setBuffer(menubutBuffer);

    SoundBuffer bubbleBuffer;
    bubbleBuffer.loadFromFile("G:\\project\\sounds\\bubbles.wav");
    Sound bubble;
    bubble.setBuffer(bubbleBuffer);

    while (OverMenu.isOpen())
    {
        Event evtMode;
        while (OverMenu.pollEvent(evtMode))
        {
            if (evtMode.type == Event::Closed)
                OverMenu.close();
            if (evtMode.type == Event::KeyReleased)
            {
                switch (evtMode.key.code)
                {
                    case sf::Keyboard::Up:
                        menubut.play();
                        gameOver.MoveUp();
                        break;
                    case sf::Keyboard::Down:
                         menubut.play();
                        gameOver.MoveDown();
                        break;
                    case sf::Keyboard::Return:
                        switch (gameOver.GetPressedItem())
                        {
                            case 3:
                                OverMenu.close();
                                bubble.play();
                                currScore = 0;
                                page = 1;
                                break;
                            case 4:
                                OverMenu.close();
                                bubble.play();
                                page = 2;
                                break;
                        }
                        break;
                }
            }
        }
        OverMenu.draw(OverBackSprite);
        gameOver.drawGameover(OverMenu);
        OverMenu.display();
    }
}
int game(int levelplatform, int levelenemy)
{
    srand(time(0));
    RenderWindow window(VideoMode(windowWidth, windowHeight), "Doodle Jump Game");
    CircleShape bullet;
    bullet.setRadius(5.0f);
    bullet.setFillColor(Color{247, 12, 126});
    bullet.setOutlineColor(Color{97, 10, 59});
    bullet.setOutlineThickness(3);
    Vector2f bulletPos(600, 0);
    window.setFramerateLimit(60);
    Texture backgroundTexture, platformTexture, playerTexture1, playerTexture2, playerTexture3, playerTexture4, jumperTexture, tampoTexture, ScorebarTexture;
    backgroundTexture.loadFromFile("G:\\project\\images\\background.png");
    platformTexture.loadFromFile("G:\\project\\images\\platform.png");
    jumperTexture.loadFromFile("G:\\project\\images\\platform-spring.png");
    tampoTexture.loadFromFile("G:\\project\\images\\platform-trampoline.png");
    playerTexture1.loadFromFile("G:\\project\\images\\doodle.png");
    playerTexture2.loadFromFile("G:\\project\\images\\doodle2.png");
    playerTexture3.loadFromFile("G:\\project\\images\\doodle2.png");
    playerTexture4.loadFromFile("G:\\project\\images\\doodle4.png");
    ScorebarTexture.loadFromFile("G:\\project\\Untitled.png");
    Sprite backgroundSprite(backgroundTexture), platformSprite(platformTexture), jumperSprite(jumperTexture), tampoSprite(tampoTexture), Scorebar(ScorebarTexture);

    Scorebar.setPosition(0, 0);
    Texture tilesTexture, tilesTexture1, tilesTexture2;
    tilesTexture.loadFromFile("G:\\project\\images\\game-tiles1.png");
    tilesTexture1.loadFromFile("G:\\project\\images\\game-tiles1.png");
    tilesTexture2.loadFromFile("G:\\project\\images\\game-tiles4.png");

    Texture pauseTexture;
    pauseTexture.loadFromFile("G:\\project\\images\\pauseButton.png");
    Sprite pauseSprite(pauseTexture);
    pauseSprite.setOrigin(pauseTexture.getSize().x / 2, pauseTexture.getSize().y / 2);
    pauseSprite.setPosition(200, 266.5);

    sf::RectangleShape enemy(sf::Vector2f(100.0f, 70.0f));
    sf::Texture enemyTexture;
    sf::Texture enemyTexture2;
    sf::Texture enemyTexture3;
    enemyTexture.loadFromFile("G:\\project\\images\\enemy.png");
    enemyTexture2.loadFromFile("G:\\project\\images\\enemy.png");
    enemyTexture3.loadFromFile("G:\\project\\images\\smoke.png");
    enemy.setTexture(&enemyTexture);
    Animation animation(&enemyTexture, sf::Vector2u(4, 1), 0.1f);
    float deltaTime = 0.0f;
    sf::Clock clock;

    sf::Vector2u textureSize = playerTexture3.getSize();

    //sound
    sf::SoundBuffer jumpBuffer;
    sf::SoundBuffer featherBuffer;
    sf::SoundBuffer lostBuffer;//
    sf::SoundBuffer monsterBuffer;//
    sf::SoundBuffer monsterDeathBuffer;//
    sf::SoundBuffer shootBuffer;
    sf::SoundBuffer trampolineBuffer;

    jumpBuffer.loadFromFile("G:\\project\\sounds\\jumparcade.wav");
    featherBuffer.loadFromFile("G:\\project\\sounds\\feather.wav");
    lostBuffer.loadFromFile("G:\\project\\sounds\\lost.wav");
    monsterBuffer.loadFromFile("G:\\project\\sounds\\monster.wav");
    monsterDeathBuffer.loadFromFile("G:\\project\\sounds\\monsterdeath.wav");
    shootBuffer.loadFromFile("G:\\project\\sounds\\shoot2.wav");
    trampolineBuffer.loadFromFile("G:\\project\\sounds\\trampoline.wav");
    sf::Sound sound;
    platform plat[levelplatform];
    for (int i = 0; i < levelplatform; i++)
    {
        plat[i].x = rand() % (windowWidth - 50);
        plat[i].y = rand() % windowHeight;
    }
    platformJump jumper[20];
    for (int i = 0; i < 1; i++)
    {
        jumper[i].x = rand() % (windowWidth - 50);
        jumper[i].y = rand() % (windowHeight + 200);
    }

    platformtampo tampoPos[20];
    for (int i = 0; i < 1; i++)
    {
        tampoPos[i].x = rand() % (windowWidth - 50);
        tampoPos[i].y = rand() % (windowHeight + 200);
    }

    EnemyS enm[levelenemy];
    for (int i = 0; i < levelenemy; i++)
    {
        enm[i].x = rand() % (windowWidth - 50);
        enm[i].y = -533 - (rand() % (windowHeight + 300));
    }
    int playerX = 100, playerY = 100, h = 200;
    float playerDY = 0;
    bool wait = true;
    while (window.isOpen())
    {
        deltaTime = clock.restart().asSeconds();

        Event evt;
        while (window.pollEvent(evt))
        {
            if (evt.type == Event::Closed)
                window.close();
        }
        Sprite playerSprite(playerTexture3);
        if (Keyboard::isKeyPressed(Keyboard::Space))
        {
            wait = false;
        }
        if (Keyboard::isKeyPressed(Keyboard::Escape))
        {
            wait = true;
        }
        if (wait == true)
        {

            if (Keyboard::isKeyPressed(Keyboard::D))
            {
                playerTexture3.update(playerTexture2);
                playerX += 3;
            }
            if (Keyboard::isKeyPressed(Keyboard::A))
            {
                playerTexture3.update(playerTexture1);
                playerX -= 3;
            }
            playerDY += 0.2;
            playerY += playerDY;
            if (playerY >= windowHeight - 33)
            {
                sound.setBuffer(lostBuffer);
                sound.play();
                window.close();
                gameIsOver();
                if (page == 1)
                {
                    game(levelplatform, levelenemy);
                }
            }
            if (playerY < h)
            {
                for (int i = 0; i < levelplatform; i++)
                { // normal platform
                    playerY = h;
                    plat[i].y = plat[i].y - playerDY;
                    if (plat[i].y > windowHeight - 20)
                    {
                        plat[i].y = 0;
                        plat[i].x = rand() % (windowWidth - 50);
                    }
                }
                for (int i = 0; i < levelenemy; i++)
                { // enemy
                    enm[i].y = enm[i].y - playerDY;
                    if (enm[i].y > windowHeight)
                    {
                        enm[i].y = 0;
                        enm[i].x = rand() % (windowWidth - 50);
                    }
                }
                for (int i = 0; i < 1; i++)
                { // jumper (platform)
                    playerY = h;
                    jumper[i].y = jumper[i].y - playerDY;
                    if (jumper[i].y > windowHeight - 20)
                    {
                        jumper[i].y = 0;
                        jumper[i].x = rand() % (windowWidth - 50);
                    }
                }
                for (int i = 0; i < 1; i++)
                { // tampo (platform)
                    playerY = h;
                    tampoPos[i].y = tampoPos[i].y - playerDY;
                    if (tampoPos[i].y > windowHeight - 20)
                    {
                        tampoPos[i].y = 0;
                        tampoPos[i].x = rand() % (windowWidth - 50);
                    }
                }
            }
            for (int i = 0; i < levelplatform; i++) // normal platform
                if ((playerX + 20 > plat[i].x) && (playerX < plat[i].x + 30) &&
                    (playerY + 70 > plat[i].y) &&
                    (playerY + 70 < plat[i].y + 14) && (playerDY > 0))
                {
                    playerDY = -10;
                    currScore += 10;
                    sound.setBuffer(jumpBuffer);
                    sound.play();
                }

            for (int i = 0; i < 1; i++) // jumper (platform)
                if ((playerX + 20 > jumper[i].x) && (playerX + 10 < jumper[i].y + 30) &&
                    (playerY + 70 > jumper[i].y) &&
                    (playerY + 70 < jumper[i].y + 14) && (playerDY > 0))
                {
                    playerDY = -20;
                    currScore += 20;
                    sound.setBuffer(featherBuffer);
                    sound.play();
                }
            for (int i = 0; i < 1; i++) // tampo
                if ((playerX + 20 > tampoPos[i].x) && (playerX + 10 < tampoPos[i].y + 30) &&
                    (playerY + 70 > tampoPos[i].y) &&
                    (playerY + 70 < tampoPos[i].y + 14) && (playerDY > 0))
                {
                    playerDY = -15;
                    currScore += 15;
                    sound.setBuffer(trampolineBuffer);
                    sound.play();
                }
            for (int i = 0; i < levelenemy; i++)
                if ((playerX + 20 > enm[i].x) && (playerX + 10 < enm[i].y + 30) &&
                    (playerY + 70 > enm[i].y) &&
                    (playerY + 70 < enm[i].y + 14) && (playerDY > 0))
                {
                    playerDY = -5;
                    currScore += 5;
                    sound.setBuffer(monsterDeathBuffer);
                    sound.play();
                    enm[i].x = 1000;
                }

            if (enm[0].x!=1000 && enm[0].y>-200 && enm[0].y<530){
                sound.setBuffer(monsterBuffer);
                sound.play();
            }
            for (int i = 0; i < levelenemy; i++)
                if ((enm[i].x <= playerX) && (playerX < enm[i].x + 80) &&
                    (playerY < enm[i].y + 50) &&
                    (playerY > enm[i].y + 10))
                {
                    sound.setBuffer(lostBuffer);
                    sound.play();
                    window.close();
                    gameIsOver();
                    if (page == 1)
                    {
                        game(levelplatform, levelenemy);
                    }
                }
            if (playerX > windowWidth)
            {
                playerX = 0.0f;
            }
            if (playerX < 0)
            {
                playerX = windowWidth;
            }

            playerSprite.setPosition(playerX, playerY);
            animation.update(0, deltaTime);
            enemy.setTextureRect(animation.uvRect);
            window.draw(backgroundSprite);
            for (int i = 0; i < levelplatform; i++)
            {
                platformSprite.setPosition(plat[i].x, plat[i].y);
                window.draw(platformSprite);
            }
            for (int i = 0; i < 1; i++)
            {
                jumperSprite.setPosition(jumper[i].x, jumper[i].y);
                window.draw(jumperSprite);
            }
            for (int i = 0; i < 1; i++)
            {
                tampoSprite.setPosition(tampoPos[i].x, tampoPos[i].y);
                window.draw(tampoSprite);
            }
            window.draw(playerSprite);
            for (int i = 0; i < levelenemy; i++)
            {
                enemy.setPosition(enm[i].x, enm[i].y);
                window.draw(enemy);
            }
            if (Keyboard::isKeyPressed(Keyboard::Key ::Enter))
            {
                sound.setBuffer(shootBuffer);
                sound.play();
                bulletPos = Vector2f(playerX + (textureSize.x / 2) - 5, playerY - 5);
                bullet.setPosition(bulletPos);
                playerTexture3.update(playerTexture4);
                window.draw(bullet);
            }
            bullet.setPosition(bulletPos);
            bulletPos.y -= 10;
            for (int i = 0; i < 1; i++)
                if ((enm[i].x <= bulletPos.x) && (bulletPos.x < enm[i].x + 100) &&
                    (bulletPos.y < enm[i].y + 20) &&
                    (bulletPos.y > enm[i].y))
                {
                    sound.setBuffer(monsterDeathBuffer);
                    sound.play();
                    enm[i].x = 1000;
                    bulletPos.x = 1000;
                }
            window.draw(bullet);
            window.draw(Scorebar);
            Score score(currScore);
            score.drawScore(window);
            window.display();
            window.clear();
        }
    }
}
int ModeGAME()
{
    RenderWindow ModeMenu(VideoMode(windowWidth, windowHeight), "Doodle Jump Game");
    Texture ModeBackTexture;
    ModeBackTexture.loadFromFile("G:\\project\\images\\mode.png");
    Sprite ModeBackSprite(ModeBackTexture);
    Mode mode(windowWidth, windowHeight);
    ModeMenu.setFramerateLimit(60);
    while (ModeMenu.isOpen())
    {
        Event evtMode;
        while (ModeMenu.pollEvent(evtMode))
        {
            if (evtMode.type == Event::Closed)
                ModeMenu.close();
            if (evtMode.type == Event ::KeyReleased)
            {
                switch (evtMode.key.code)
                {
                    case sf::Keyboard::Up:
                        mode.MoveUp();
                        break;
                    case sf::Keyboard::Down:
                        mode.MoveDown();
                        break;
                    case sf::Keyboard::Return:
                        switch (mode.GetPressedItem())
                        {
                            case 0:
                                ModeMenu.close();
                                game(20, 1);
                                break;
                            case 2:
                                ModeMenu.close();
                                game(10, 2);
                                break;
                        }
                        break;
                }
            }
        }
        ModeMenu.draw(ModeBackSprite);
        mode.drawMode(ModeMenu);
        ModeMenu.display();
    }
}
int MenugameEasy()
{
    RenderWindow MainMenu(VideoMode(windowWidth, windowHeight), "Doodle Jump Game");
    Texture MenubackTexture;
    MenubackTexture.loadFromFile("G:\\project\\images\\Menu.png");
    Sprite Menuback(MenubackTexture);
    Menu menu(windowWidth, windowHeight);
    MainMenu.setFramerateLimit(60);

    sf::Font doodleFont;
    doodleFont.loadFromFile("G:\\project\\DoodleJump.ttf");
    TextBox textBox(26, sf::Color::White, false);
    textBox.setFont(doodleFont);
    textBox.setPosition({windowWidth / 2 - 30.f, windowHeight - 42.f});
    textBox.setLimit(true, 10);

    sf::SoundBuffer bubbleBuffer;
    sf::SoundBuffer menubutBuffer;
    sf::SoundBuffer gameTheme;


    bubbleBuffer.loadFromFile("G:\\project\\sounds\\bubbles.wav");
    menubutBuffer.loadFromFile("G:\\project\\sounds\\menuBut.wav");
    gameTheme.loadFromFile("G:\\project\\sounds\\game.wav");

    Sound bubble;
    Sound menubut;
    Sound theme;
    bubble.setBuffer(bubbleBuffer);
    menubut.setBuffer(menubutBuffer);
    theme.setBuffer(gameTheme);
    theme.setVolume(20);
    theme.play();
    while (MainMenu.isOpen())
    {

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
        {
            textBox.setSelected(true);
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
        {
            textBox.setSelected(false);
        }
        Event evtMain;
        while (MainMenu.pollEvent(evtMain))
        {
            if (evtMain.type == Event::Closed)
                MainMenu.close();
            switch (evtMain.type)
            {
                case sf::Event::TextEntered:
                    textBox.typeOn(evtMain);
            }
            if (evtMain.type == Event ::KeyReleased)
            {
                switch (evtMain.key.code)
                {
                    case sf::Keyboard::Up:
                        menubut.play();
                        menu.MoveUp();
                        break;
                    case sf::Keyboard::Down:
                        menubut.play();
                        menu.MoveDown();
                        break;
                    case sf::Keyboard::Return:
                        switch (menu.GetPressedItem())
                        {
                            case 0:
                                theme.stop();
                                MainMenu.close();
                                bubble.play();
                                myname = textBox.Returner();
                                game(20, 1);
                                if (page == 2)
                                {
                                    MenugameEasy();
                                }
                                break;
                            case 1:
                                theme.stop();
                                MainMenu.close();
                                bubble.play();
                                myname = textBox.Returner();
                                ModeGAME();
                                if (page == 2)
                                {
                                    MenugameEasy();
                                }
                                break;
                            case 2:
                                theme.stop();
                                MainMenu.close();
                                break;
                        }
                        break;
                }
            }
        }
        MainMenu.draw(Menuback);
        menu.draw(MainMenu);
        textBox.drawTo(MainMenu);
        MainMenu.display();
    }
}
int MenugameHard()
{
    RenderWindow MainMenu(VideoMode(windowWidth, windowHeight), "Doodle Jump Game");
    Texture MenubackTexture;
    MenubackTexture.loadFromFile("G:\\project\\images\\Menu.png");
    Sprite Menuback(MenubackTexture);
    Menu menu(windowWidth, windowHeight);
    MainMenu.setFramerateLimit(60);

    sf::Font doodleFont;
    doodleFont.loadFromFile("G:\\project\\DoodleJump.ttf");
    TextBox textBox(26, sf::Color::White, false);
    textBox.setFont(doodleFont);
    textBox.setPosition({windowWidth / 2 - 30.f, windowHeight - 42.f});
    textBox.setLimit(true, 10);

     sf::SoundBuffer bubbleBuffer;
    sf::SoundBuffer menubutBuffer;
    sf::SoundBuffer gameTheme;


    bubbleBuffer.loadFromFile("G:\\project\\sounds\\bubbles.wav");
    menubutBuffer.loadFromFile("G:\\project\\sounds\\menuBut.wav");
    gameTheme.loadFromFile("G:\\project\\sounds\\game.wav");

    Sound bubble;
    Sound menubut;
    Sound theme;
    bubble.setBuffer(bubbleBuffer);
    menubut.setBuffer(menubutBuffer);
    theme.setBuffer(gameTheme);
    theme.setVolume(50);
    theme.play();
    while (MainMenu.isOpen())
    {

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
        {
            textBox.setSelected(true);
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
        {
            textBox.setSelected(false);
        }

        Event evtMain;
        while (MainMenu.pollEvent(evtMain))
        {
            if (evtMain.type == Event::Closed)
                MainMenu.close();
            switch (evtMain.type)
            {
                case sf::Event::TextEntered:
                    textBox.typeOn(evtMain);
            }
            if (evtMain.type == Event ::KeyReleased)
            {
                switch (evtMain.key.code)
                {
                    case sf::Keyboard::Up:
                        menubut.play();
                        menu.MoveUp();
                        break;
                    case sf::Keyboard::Down:
                        menubut.play();
                        menu.MoveDown();
                        break;
                    case sf::Keyboard::Return:
                        switch (menu.GetPressedItem())
                        {
                            case 0:
                                theme.stop();
                                MainMenu.close();
                                bubble.play();
                                myname = textBox.Returner();
                                game(10, 2);
                                if (page == 2)
                                {
                                    MenugameHard();
                                }
                                break;
                            case 1:
                                theme.stop();
                                MainMenu.close();
                                bubble.play();
                                myname = textBox.Returner();
                                MainMenu.close();
                                ModeGAME();
                                if (page == 2)
                                {
                                    MenugameHard();
                                }
                                break;
                            case 2:
                                theme.stop();
                                MainMenu.close();
                                break;
                        }
                        break;
                }
            }
        }
        MainMenu.draw(Menuback);
        menu.draw(MainMenu);
        textBox.drawTo(MainMenu);
        MainMenu.display();
    }
}
#endif // PROJECT_FUNCTIONS_H
