//
// Created by Arshia 7/5/2023.
//

#include "Mode.h"
Mode::Mode(float width, float height) {
    if(!fontMode.loadFromFile("G:\\project\\DoodleJump.ttf")){
        //handle error
    }
    mode[0].setFont(fontMode);
    mode[0].setOutlineColor({128, 9, 9});
    mode[0].setOutlineThickness(2);
    mode[0].setColor(sf::Color::Red);
    mode[0].setString("< Easy >");
    mode[0].setPosition(sf::Vector2f(width/2+35,height/(MAX_NUM + 1)*1.5 - 10));


    mode[1].setFont(fontMode);
    mode[1].setColor(sf::Color::Yellow);
    mode[1].setOutlineColor({232, 182, 2});
    mode[1].setOutlineThickness(2);
    mode[1].setCharacterSize(50);
    mode[1].setString("Difficulty :");
    mode[1].setPosition(sf::Vector2f(width/2-170,height/(MAX_NUM + 1)*2 -27));


    mode[2].setFont(fontMode);
    mode[2].setColor(sf::Color::Black);
    mode[2].setOutlineColor({107, 103, 103});
    mode[2].setOutlineThickness(2);
    mode[2].setString("< Hard >");
    mode[2].setPosition(sf::Vector2f(width/2+35,height/(MAX_NUM + 1)*2.5 -10));

    selectedItemsIndexMode=0;

}
void Mode::drawMode(sf::RenderWindow &window) {
    for(int i=0;i<MAX_NUM;i++){
        window.draw(mode[i]);
    }
}
void Mode::MoveUp() {
    if(selectedItemsIndexMode-1>0 && selectedItemsIndexMode!=1){
        mode[selectedItemsIndexMode].setColor(sf::Color::Black);
        mode[selectedItemsIndexMode].setOutlineColor({107, 103, 103});
        selectedItemsIndexMode =0;
        mode[selectedItemsIndexMode].setColor(sf::Color::Red);
        mode[selectedItemsIndexMode].setOutlineColor({128, 9, 9});
    }
}
void Mode::MoveDown()  {
    if(selectedItemsIndexMode==0 && selectedItemsIndexMode!=1){
        mode[selectedItemsIndexMode].setColor(sf::Color::Black);
        mode[selectedItemsIndexMode].setOutlineColor({107, 103, 103});
        selectedItemsIndexMode =2;
        mode[selectedItemsIndexMode].setColor(sf::Color::Red);
        mode[selectedItemsIndexMode].setOutlineColor({128, 9, 9});
    }
}