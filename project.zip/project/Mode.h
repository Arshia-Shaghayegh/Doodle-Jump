//
// Created by Arshia 7/5/2023.
//
#include "SFML/Graphics.hpp"
#define  MAX_NUM 3
#ifndef PROJECT_MODE_H
#define PROJECT_MODE_H


class Mode {
public:
    Mode(float width,float height);

    void drawMode(sf:: RenderWindow &window);
    void MoveUp();
    void MoveDown();
    int GetPressedItem(){
        return  selectedItemsIndexMode;
    }
private:
    int selectedItemsIndexMode;
    sf::Font fontMode;
    sf::Text mode[MAX_NUM];

};


#endif //PROJECT_MODE_H
